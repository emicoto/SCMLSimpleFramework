
DefineMacroS('setStage', setStage);
DefineMacroS('unsetStage', unsetStage);
DefineMacro('iEventHeader', SFE_onHeader);
