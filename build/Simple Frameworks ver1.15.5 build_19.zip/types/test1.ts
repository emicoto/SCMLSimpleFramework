const a = new NamedNPC('', '', '', '');
const b = new NamedNPC('', '', '', '');

[].randompop();
''.randompop();
''.toCamelCase();
[].has();

window.roll(1, 1);

window.SimplePatchPassage.patchPassage(a as any, '');
window.SimplePatchPassage.patchedPassage;

window.SelectCase
window.check.好感('')
window.cntv.变量('')

setup.addNPCList.randompop();

window.iMod.init('');

setup.dolbus.randompop();
