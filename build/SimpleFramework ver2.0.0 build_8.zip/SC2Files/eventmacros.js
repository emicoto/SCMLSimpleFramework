
DefineMacroS('setStage', setStage);
DefineMacroS('unsetStage', unsetStage);
